# Empire Heart Backend

Simple Express server.

## How to run

1. Install dependencies
   ```
   npm install
   ```

2. Start the server
   ```
   npm start
   ```

Server runs on **http://localhost:3000**
